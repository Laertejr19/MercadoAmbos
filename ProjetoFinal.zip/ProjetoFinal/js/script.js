import { db } from './firebaseConfig.js';
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

function getInput(){
    return {
        nomeCliente: document.getElementById("nomeCliente"),
        valorConta: document.getElementById("valorConta"),           
        dataVencC: document.getElementById("dataVencC"),
        jurosC: document.getElementById("jurosC"),  
        statusC: document.getElementById("statusC")
    }
}

function getValores({nomeCliente, valorConta, dataVencC, jurosC, statusC}){
    return{
        nomeCliente: nomeCliente.value.trim(),
        valorConta: parseFloat(valorConta.value),
        dataVencC: dataVencC.value,
        jurosC: parseFloat(jurosC.value),
        statusC: statusC.value
    }
}

document.getElementById("btnCadastrar").addEventListener("click", async function(){
    const input = getInput();

    const camposObrigatorios = [
        input.nomeCliente.value.trim(),
        input.valorConta.value.trim(),
        input.dataVencC.value,
        input.jurosC.value.trim(),
        input.statusC.value
    ];
    
    if (camposObrigatorios.some(valor => !valor)) {
        alert('Por favor, preencha todos os campos antes de cadastrar.');
        return;
    }
    
    const dados = getValores(input);
    
    if (valorConta < 0 || jurosC < 0) {
        alert('Os valores não podem ser negativos!');
        return;
    }
    console.log("Dados",dados)

    try{
        const ref = await addDoc(collection(db, "contas"), dados)
        console.log("ID do documento", ref.id)
        alert("A conta foi cadastrada com sucesso!")
    } catch (e){
        console.log("Erro:", e)
    }
});