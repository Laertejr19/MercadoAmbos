import { db } from './firebaseConfig.js';
import { collection, addDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

function getInput(){
    return {
        nomeFornecedor: document.getElementById("nomeFornecedor"),
        valorBoleto: document.getElementById("valorBoleto"),
        dataVencF: document.getElementById("dataVencF"),
        jurosF: document.getElementById("jurosF"),   
        statusF: document.getElementById("statusF")
    }
}

function getValores({nomeFornecedor, valorBoleto, dataVencF, jurosF, statusF}){
    return{
        nomeFornecedor: nomeFornecedor.value.trim(),
        valorBoleto: parseFloat(valorBoleto.value),        
        dataVencF: dataVencF.value,
        jurosF: parseFloat(jurosF.value),
        statusF: statusF.value
    }
}

document.getElementById("btnCadastrar").addEventListener("click", async function(){
    const input = getInput();

    const camposObrigatorios = [
        input.nomeFornecedor.value.trim(),
        input.valorBoleto.value.trim(),
        input.dataVencF.value,
        input.jurosF.value.trim(),
        input.statusF.value
    ];
    
    if (camposObrigatorios.some(valor => !valor)) {
        alert('Por favor, preencha todos os campos antes de cadastrar.');
        return;
    }
    
    const dados = getValores(input);
    
    if (valorBoleto < 0 || jurosF < 0) {
        alert('Os valores não podem ser negativos!');
        return;
    }
    console.log("Dados",dados)

    try{
        const ref = await addDoc(collection(db, "boletos"), dados)
        console.log("ID do documento", ref.id)
        alert("O boleto foi cadastrado com sucesso!")
    } catch (e){
        console.log("Erro:", e)
    }

});