
import { db } from "./firebaseConfig.js";
import { collection, getDocs, deleteDoc, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarContas() {
    try {
        const dadosBanco = await getDocs(collection(db, "contas"));
        const contas = [];

        for (const doc of dadosBanco.docs) {
            contas.push({ id: doc.id, ...doc.data() });
        }

        return contas;
    } catch (erro) {
        console.log("Erro ao buscar contas: ", erro);
        return [];
    }
}

let listaContasDiv;

async function carregarListaDeContas() {
    listaContasDiv = document.getElementById("listar-contas");
    if (!listaContasDiv) {
        console.log('Elemento #listar-contas não encontrado no DOM');
        return;
    }
    listaContasDiv.innerHTML = '<p> Carregando lista de contas ... </p>';
    try{
        const contas = await buscarContas();
        console.log(contas);
        renderizarListaDeContas(contas);
    }catch(error){
        console.log("Erro ao carregar a lista de contas: ", error);
        listaContasDiv.innerHTML = '<p> Erro ao carregar a lista de contas </p>';
    }
}

function renderizarListaDeContas(contas) {
    listaContasDiv.innerHTML = "";
    if (contas.length === 0) {
        listaContasDiv.innerHTML = '<p> Nenhuma conta cadastrada ainda! </p>';
        return;
    }

    for (let conta of contas) {
        const contaDiv = document.createElement("div");
        contaDiv.classList.add('conta-item');
        const valor = (typeof conta.valorConta === 'number') ? conta.valorConta.toFixed(2) : parseFloat(conta.valorConta || 0).toFixed(2);
        const valorTotal = calcularValorTotalComJuros(conta);
        const valorPago = parseFloat(conta.valorPago || 0);
        const restante = calcularValorRestante(conta, valorTotal);
        contaDiv.innerHTML = `
        <strong> Nome: </strong> ${conta.nomeCliente} <br>
        <strong> Valor: </strong> R$ ${valor} <br>
        <strong> Data de Vencimento: </strong> ${conta.dataVencC} <br>
        <strong> Prazo: </strong> ${calcularDiasVencimento(conta.dataVencC)} <br>
        <strong> Juros: </strong> ${conta.jurosC}% <br>
        <strong> Status: </strong> ${conta.statusC || "Em aberto"} <br>
        <strong> Valor Total: </strong> R$ ${valorTotal.toFixed(2)} <br>
        <strong> Valor Pago: </strong> R$ ${valorPago.toFixed(2)} <br>
        <strong> Valor Restante: </strong> R$ ${restante.toFixed(2)} <br>
        <button class="btn-Pagar" data-id="${conta.id}">Pagar</button>
        <button class="btn-Excluir" data-id="${conta.id}"> Excluir </button>
        `
        listaContasDiv.appendChild(contaDiv);
    }
}



async function excluirConta(idConta) {
    try {
        const documentoDeletar = doc(db, "contas", idConta);
        await deleteDoc(documentoDeletar);
        console.log("Conta com ID " + idConta + " foi excluída.");
        return true;
    } catch (erro) {
        console.log("Erro ao excluir conta", erro);
        alert("Ocorreu um erro ao excluir a conta. Tente novamente!");
        return false;
    }
}

function calcularValorTotalComJuros(conta) {
    const valorBase = parseFloat(conta.valorConta || 0);
    const juros = parseFloat(conta.jurosC || 0);
    const dias = getDiasVencimento(conta.dataVencC);
    const diasAtraso = dias < 0 ? Math.abs(dias) : 0;

    return valorBase + (valorBase * (juros / 100) * diasAtraso);
}

function calcularValorRestante(conta, valorTotal) {
    const pago = parseFloat(conta.valorPago || 0);
    return Math.max(0, valorTotal - pago);
}

async function pagarConta(id, valorParcela) {
    try {
        const ref = doc(db, "contas", id);
        const snap = await getDoc(ref);
        if (!snap.exists()) return false;

        const conta = snap.data();
        const total = calcularValorTotalComJuros(conta);
        const pagoAtual = parseFloat(conta.valorPago || 0);

        if (valorParcela > (total - pagoAtual)) {
            alert("Valor maior que o restante!");
            return false;
        }

        const novoPago = pagoAtual + valorParcela;
        const status = novoPago >= total ? "Pago" : "Parcial";

        await setDoc(ref, {
            valorPago: novoPago,
            statusC: status
        }, { merge: true });

        return true;

    } catch (erro) {
        console.error("Erro ao pagar", erro);
        return false;
    }
}

let edicao = null;

function calcularDiasVencimento(dataVenc) {
    if (!dataVenc) return 'Data inválida';
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 'Data inválida';
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);
    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    if (Number.isNaN(diffDias)) return 'Data inválida';
    if (diffDias > 0) return `Faltam ${diffDias} dia${diffDias > 1 ? 's' : ''}`;
    if (diffDias === 0) return 'Vence hoje';
    return `Vencido há ${Math.abs(diffDias)} dia${Math.abs(diffDias) > 1 ? 's' : ''}`;
}

function getDiasVencimento(dataVenc) {
    if (!dataVenc) return 0;
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 0;
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);
    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    return Number.isNaN(diffDias) ? 0 : diffDias;
}


window.addEventListener("DOMContentLoaded", carregarListaDeContas);
document.addEventListener("click", async e => {
    document.addEventListener("click", async e => {
        if (e.target.classList.contains("btn-Excluir")) {
            if (!confirm("Deseja excluir esta conta?")) return;
            await excluirConta(e.target.dataset.id);
            carregarListaDeContas();
        }


        if (e.target.classList.contains("btn-Pagar")) {
            const contaId = e.target.dataset.id;
            mostrarModalPagamento(contaId);
        }
    });

    function mostrarModalPagamento(contaId) {

        const modal = document.getElementById("modal-pagamento");
        const inputPagamento = document.getElementById("valor-pagamento");

        modal.style.display = "block";
        inputPagamento.value = "";


        const confirmarPagamento = document.getElementById("confirmar-pagamento");

        confirmarPagamento.onclick = async () => {
            const valorParcela = parseFloat(inputPagamento.value);
            if (isNaN(valorParcela) || valorParcela <= 0) {
                alert("Valor inválido");
                return;
            }

            const sucesso = await pagarConta(contaId, valorParcela);
            if (sucesso) {
                carregarListaDeContas();
                fecharModal();
            }
        };

        const closeModal = document.getElementById("close-modal");
        closeModal.onclick = fecharModal;
    }

    function fecharModal() {
        const modal = document.getElementById("modal-pagamento");
        modal.style.display = "none";
    }
});