
const tipoPagina = window.location.pathname.includes("pagina2") ? "receber" : "pagar";


function carregar() {
    const dados = JSON.parse(localStorage.getItem("contas_" + tipoPagina)) || [];
    dados.forEach(item => criarCard(item));
}

function criarCard(d) {
    const area = document.querySelector(".content-left");
    const card = document.createElement("div");
    card.className = "card";
    card.dataset.id = d.id;

    card.innerHTML = `
        <p>Nome: ${d.nome}</p>
        <p>Valor: R$ ${d.valor.toFixed(2)}</p>
        <p>Data de Vencimento: ${d.venc}</p>
        <p>Juros: ${d.juros}%</p>
        <p>Status: ${d.status}</p>
        <div class="button-group-top">
            <button class="btn-excluir">Excluir</button>
        </div>
    `;

    card.querySelector(".btn-excluir").onclick = () => excluir(card.dataset.id, card);

    area.appendChild(card);
}

function excluir(id, card) {
    card.remove();
    let dados = JSON.parse(localStorage.getItem("contas_" + tipoPagina)) || [];
    dados = dados.filter(x => x.id !== id);
    localStorage.setItem("contas_" + tipoPagina, JSON.stringify(dados));
}

window.addEventListener("DOMContentLoaded", carregar);
