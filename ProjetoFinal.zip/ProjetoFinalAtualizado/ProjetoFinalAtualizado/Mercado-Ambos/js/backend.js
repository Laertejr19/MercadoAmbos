function ExcluirCard(botaoClicado){

    const CardRemovido = botaoClicado.parentNode;

    const container = CardRemovido.parentNode;

    container.removeChild(CardRemovido);

    console.log("Card removido com sucesso!");
}