
import { db } from "./firebaseConfig.js";
import { collection, getDocs, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarContas() {
    try {
        const dadosBanco = await getDocs(collection(db, "contas"));
        const contas = [];

        for (const doc of dadosBanco.docs) {
            contas.push({ id: doc.id, ...doc.data() });
        }

        return contas;
    } catch (erro) {
        console.log("Erro ao buscar contas: ", erro);
        return [];
    }
}

let listaContasDiv;

async function carregarListaDeContas() {
    listaContasDiv = document.getElementById("listar-contas");
    if (!listaContasDiv) {
        console.log('Elemento #listar-contas não encontrado no DOM');
        return;
    }
    listaContasDiv.innerHTML = '<p> Carregando lista de contas ... </p>';
    try{
        const contas = await buscarContas();
        console.log(contas);
        renderizarListaDeContas(contas);
    }catch(error){
        console.log("Erro ao carregar a lista de contas: ", error);
        listaContasDiv.innerHTML = '<p> Erro ao carregar a lista de contas </p>';
    }
}

function renderizarListaDeContas(contas) {
    listaContasDiv.innerHTML = "";
    if (contas.length === 0) {
        listaContasDiv.innerHTML = '<p> Nenhuma conta cadastrada ainda ;( </p>';
        return;
    }

    for (let conta of contas) {
        const contaDiv = document.createElement("div");
        contaDiv.classList.add('conta-item');
        contaDiv.innerHTML = `
        <strong> Nome: </strong> ${conta.nomeCliente} <br>
        <strong> Valor: </strong> R$ ${conta.valorConta.toFixed(2)} <br>
        <strong> Data de Vencimento: </strong> ${conta.dataVencC} <br>
        <strong> Juros: </strong> ${conta.jurosC}% <br>
        <strong> Status: </strong> ${conta.statusC} <br>
        <button class="btn-Excluir" data-id="${conta.id}"> Excluir </button>
        `
        listaContasDiv.appendChild(contaDiv);
    }
    
}

async function excluirConta(idConta) {
    try {
        const documentoDeletar = doc(db, "contas", idConta);
        await deleteDoc(documentoDeletar);
        console.log("Conta com ID " + idConta + " foi excluída.");
        return true;
    } catch (erro) {
        console.log("Erro ao excluir conta", erro);
        alert("Ocorreu um erro ao excluir a conta. Tente novamente!");
        return false;
    }
}

let edicao = null;

async function lidarClique(eventoDeClique){
    const btnExcluir = eventoDeClique.target.closest('.btn-Excluir');
    if (btnExcluir) {
        const idConta = btnExcluir.getAttribute('data-id');
        const sucesso = await excluirConta(idConta);
        if (sucesso) {
            carregarListaDeContas();
        }
    }
}

window.addEventListener("DOMContentLoaded", carregarListaDeContas);
document.addEventListener('click', lidarClique);