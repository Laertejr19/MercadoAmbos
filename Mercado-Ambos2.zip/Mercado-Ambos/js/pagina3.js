import { db } from './firebaseConfig.js';
import { collection, addDoc, getDocs, deleteDoc, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarBoletos() {
    try {
        const dadosBanco = await getDocs(collection(db, "boletos"));
        const boletos = [];

        for (const doc of dadosBanco.docs) {
            boletos.push({ id: doc.id, ...doc.data() });
        }

        return boletos;
    } catch (erro) {
        console.log("Erro ao buscar boletos: ", erro);
        return [];
    }
}

let listaBoletosDiv;

async function carregarListaDeBoletos() {
    listaBoletosDiv = document.getElementById("listar-boletos");
    if (!listaBoletosDiv) {
        console.log('Elemento #listar-boletos não encontrado no DOM');
        return;
    }
    listaBoletosDiv.innerHTML = '<p> Carregando lista de boletos ... </p>';
    try{
        const boletos = await buscarBoletos();
        console.log(boletos);
        renderizarListaDeBoletos(boletos);
    }catch(error){
        console.log("Erro ao carregar a lista de boletos: ", error);
        listaBoletosDiv.innerHTML = '<p> Erro ao carregar a lista de boletos </p>';
    }
}

function renderizarListaDeBoletos(boletos) {
    listaBoletosDiv.innerHTML = "";
    if (boletos.length === 0) {
        listaBoletosDiv.innerHTML = '<p> Nenhum boleto cadastrado ainda! </p>';
        return;
    }

    for (let boleto of boletos) {
        const boletoDiv = document.createElement("div");
        boletoDiv.classList.add('boleto-item');
        boletoDiv.innerHTML = `
        <strong> Fornecedor: </strong> ${boleto.nomeFornecedor} <br>
        <strong> Valor: </strong> R$ ${boleto.valorBoleto.toFixed(2)} <br>
        <strong> Data de Vencimento: </strong> ${boleto.dataVencF} <br>
        <strong> Juros: </strong> ${boleto.jurosF}% <br>
        <strong> Status: </strong> ${boleto.statusF} <br>
        <button class="btn-Excluir" data-id="${boleto.id}"> Excluir </button>
        `
        listaBoletosDiv.appendChild(boletoDiv);
    }
    
}

async function excluirBoleto(idBoleto) {
    try {
        const documentoDeletar = doc(db, "boletos", idBoleto);
        await deleteDoc(documentoDeletar);
        console.log("Boleto com ID " + idBoleto + " foi excluído.");
        return true;
    } catch (erro) {
        console.log("Erro ao excluir boleto", erro);
        alert("Ocorreu um erro ao excluir o boleto. Tente novamente!");
        return false;
    }
}

let edicao = null;

async function lidarClique(eventoDeClique){
    const btnExcluir = eventoDeClique.target.closest('.btn-Excluir');
    if (btnExcluir) {
        const idBoleto = btnExcluir.getAttribute('data-id');
        const sucesso = await excluirBoleto(idBoleto);
        if (sucesso) {
            carregarListaDeBoletos();
        }
    }
}

window.addEventListener("DOMContentLoaded", carregarListaDeBoletos);
document.addEventListener('click', lidarClique);