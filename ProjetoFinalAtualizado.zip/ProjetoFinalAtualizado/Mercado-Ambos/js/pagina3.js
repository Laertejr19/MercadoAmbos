import { db } from './firebaseConfig.js';
import {
    collection,
    getDocs,
    deleteDoc,
    doc,
    getDoc,
    setDoc
} from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarBoletos() {
    try {
        const snap = await getDocs(collection(db, "boletos"));
        return snap.docs.map(d => ({ id: d.id, ...d.data() }));
    } catch (erro) {
        console.error("Erro ao buscar boletos", erro);
        return [];
    }
}

let listaBoletosDiv;

async function carregarListaDeBoletos() {
    listaBoletosDiv = document.getElementById("listar-boletos");
    if (!listaBoletosDiv) return;

    listaBoletosDiv.innerHTML = "<p>Carregando boletos...</p>";

    try {
        const boletos = await buscarBoletos();
        renderizarListaDeBoletos(boletos);
    } catch {
        listaBoletosDiv.innerHTML = "<p>Erro ao carregar boletos</p>";
    }
}

function diferencaDias(dataVenc) {
    if (!dataVenc) return null;
    const [ano, mes, dia] = dataVenc.split('-').map(Number);
    if (!ano || !mes || !dia) return null;

    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0, 0, 0, 0);
    venc.setHours(0, 0, 0, 0);

    const diff = Math.round((venc - hoje) / 86400000);
    return Number.isNaN(diff) ? null : diff;
}

function calcularPrazo(dataVenc) {
    const dias = diferencaDias(dataVenc);
    if (dias === null) return "Data inválida";
    if (dias > 0) return `Faltam ${dias} dia${dias > 1 ? 's' : ''}`;
    if (dias === 0) return "Vence hoje";
    return `Vencido há ${Math.abs(dias)} dia${Math.abs(dias) > 1 ? 's' : ''}`;
}

function calcularValorTotalComJuros(boleto) {
    const valorBase = parseFloat(boleto.valorBoleto || 0);
    const juros = parseFloat(boleto.jurosF || 0);
    const dias = diferencaDias(boleto.dataVencF);
    const diasAtraso = dias < 0 ? Math.abs(dias) : 0;

    return valorBase + (valorBase * (juros / 100) * diasAtraso);
}

function calcularValorRestante(boleto, valorTotal) {
    const pago = parseFloat(boleto.valorPago || 0);
    return Math.max(0, valorTotal - pago);
}

function renderizarListaDeBoletos(boletos) {
    listaBoletosDiv.innerHTML = "";

    if (boletos.length === 0) {
        listaBoletosDiv.innerHTML = "<p>Nenhum boleto cadastrado</p>";
        return;
    }

    boletos.forEach(boleto => {
        const valorTotal = calcularValorTotalComJuros(boleto);
        const valorPago = parseFloat(boleto.valorPago || 0);
        const restante = calcularValorRestante(boleto, valorTotal);

        const div = document.createElement("div");
        div.className = "boleto-item";

        div.innerHTML = `
            <strong>Fornecedor:</strong> ${boleto.nomeFornecedor}<br>
            <strong>Valor Original:</strong> R$ ${parseFloat(boleto.valorBoleto).toFixed(2)}<br>
            <strong>Juros:</strong> ${boleto.jurosF || 0}% ao dia<br>
            <strong>Vencimento:</strong> ${boleto.dataVencF}<br>
            <strong>Prazo:</strong> ${calcularPrazo(boleto.dataVencF)}<br>
            <strong>Status:</strong> ${boleto.statusF || "Em aberto"}<br>

            <hr>

            <strong>Valor Total:</strong> R$ ${valorTotal.toFixed(2)}<br>
            <strong>Valor Pago:</strong> R$ ${valorPago.toFixed(2)}<br>
            <strong>Valor Restante:</strong> R$ ${restante.toFixed(2)}<br>

            <button class="btn-Pagar" data-id="${boleto.id}">Pagar</button>
            <button class="btn-Excluir" data-id="${boleto.id}">Excluir</button>
        `;

        listaBoletosDiv.appendChild(div);
    });
}

async function pagarBoleto(id, valorParcela) {
    try {
        const ref = doc(db, "boletos", id);
        const snap = await getDoc(ref);
        if (!snap.exists()) return false;

        const boleto = snap.data();
        const total = calcularValorTotalComJuros(boleto);
        const pagoAtual = parseFloat(boleto.valorPago || 0);

        if (valorParcela > (total - pagoAtual)) {
            alert("Valor maior que o restante!");
            return false;
        }

        const novoPago = pagoAtual + valorParcela;
        const status = novoPago >= total ? "Pago" : "Parcial";

        await setDoc(ref, {
            valorPago: novoPago,
            statusF: status
        }, { merge: true });

        return true;

    } catch (erro) {
        console.error("Erro ao pagar", erro);
        return false;
    }
}

async function excluirBoleto(id) {
    try {
        await deleteDoc(doc(db, "boletos", id));
        return true;
    } catch {
        alert("Erro ao excluir boleto");
        return false;
    }
}

document.addEventListener("click", async e => {

    if (e.target.classList.contains("btn-Excluir")) {
        if (!confirm("Deseja excluir este boleto?")) return;
        await excluirBoleto(e.target.dataset.id);
        carregarListaDeBoletos();
    }

    if (e.target.classList.contains("btn-Pagar")) {
        const valor = prompt("Digite o valor da parcela:");
        const parcela = parseFloat(valor);
        if (isNaN(parcela) || parcela <= 0) return alert("Valor inválido");

        const sucesso = await pagarBoleto(e.target.dataset.id, parcela);
        if (sucesso) carregarListaDeBoletos();
    }
    document.addEventListener("click", async e => {

        if (e.target.classList.contains("btn-Excluir")) {
            if (!confirm("Deseja excluir este boleto?")) return;
            await excluirBoleto(e.target.dataset.id);
            carregarListaDeBoletos();
        }


        if (e.target.classList.contains("btn-Pagar")) {
            const boletoId = e.target.dataset.id;
            mostrarModalPagamento(boletoId);
        }
    });

    function mostrarModalPagamento(boletoId) {

        const modal = document.getElementById("modal-pagamento");
        const inputPagamento = document.getElementById("valor-pagamento");

        modal.style.display = "block";
        inputPagamento.value = "";


        const confirmarPagamento = document.getElementById("confirmar-pagamento");

        confirmarPagamento.onclick = async () => {
            const valorParcela = parseFloat(inputPagamento.value);
            if (isNaN(valorParcela) || valorParcela <= 0) {
                alert("Valor inválido");
                return;
            }

            const sucesso = await pagarBoleto(boletoId, valorParcela);
            if (sucesso) {
                carregarListaDeBoletos();
                fecharModal();
            }
        };

        const closeModal = document.getElementById("close-modal");
        closeModal.onclick = fecharModal;
    }

    function fecharModal() {
        const modal = document.getElementById("modal-pagamento");
        modal.style.display = "none";
    }

});

window.addEventListener("DOMContentLoaded", carregarListaDeBoletos);