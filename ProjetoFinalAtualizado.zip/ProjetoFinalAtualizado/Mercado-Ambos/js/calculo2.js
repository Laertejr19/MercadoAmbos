function calcularJurosFornecedor() {
    const jurosVal = parseFloat(document.getElementById('jurosF')?.value);
    const mesVal = parseFloat(document.getElementById('mesF')?.value);
    const valorVal = parseFloat(document.getElementById('valorF')?.value);

    if (Number.isNaN(jurosVal) || Number.isNaN(mesVal) || Number.isNaN(valorVal)) {
        document.getElementById('valorTotalF').innerText = 'É necessário informar os dias corretamente.';
        return;
    }

    const valorTotalF = valorVal + (valorVal * (jurosVal / 100) * mesVal);

    document.getElementById('valorTotalF').innerText = valorTotalF.toFixed(2);
}

window.calcularJurosFornecedor = calcularJurosFornecedor;