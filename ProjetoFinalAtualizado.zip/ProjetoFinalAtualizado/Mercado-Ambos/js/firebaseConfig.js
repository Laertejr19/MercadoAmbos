import { initializeApp } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-app.js";
  import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-analytics.js";
  import { getFirestore } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";
 
  const firebaseConfig = {
    apiKey: "AIzaSyDAPAjlG-b5RNcV6yw_EFVK_OF5OxN8krQ",
    authDomain: "mercado-ambos.firebaseapp.com",
    databaseURL: "https://mercado-ambos-default-rtdb.firebaseio.com",
    projectId: "mercado-ambos",
    storageBucket: "mercado-ambos.firebasestorage.app",
    messagingSenderId: "373680141762",
    appId: "1:373680141762:web:cdc8efd03cb0c5541f525b",
    measurementId: "G-CEBRWMHM22"
  };

const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);

export { db, app };