import { db } from './firebaseConfig.js';
import { collection, addDoc, getDocs, deleteDoc, doc, getDoc, setDoc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarBoletos() {
    try {
        const dadosBanco = await getDocs(collection(db, "boletos"));
        const boletos = [];

        for (const doc of dadosBanco.docs) {
            boletos.push({ id: doc.id, ...doc.data() });
        }

        return boletos;
    } catch (erro) {
        console.log("Erro ao buscar boletos: ", erro);
        return [];
    }
}

let listaBoletosDiv;

async function carregarListaDeBoletos() {
    listaBoletosDiv = document.getElementById("listar-boletos");
    if (!listaBoletosDiv) {
        console.log('Elemento #listar-boletos não encontrado no DOM');
        return;
    }
    listaBoletosDiv.innerHTML = '<p> Carregando lista de boletos ... </p>';
    try{
        const boletos = await buscarBoletos();
        console.log(boletos);
        renderizarListaDeBoletos(boletos);
    }catch(error){
        console.log("Erro ao carregar a lista de boletos: ", error);
        listaBoletosDiv.innerHTML = '<p> Erro ao carregar a lista de boletos </p>';
    }
}

function renderizarListaDeBoletos(boletos) {
    listaBoletosDiv.innerHTML = "";
    if (boletos.length === 0) {
        listaBoletosDiv.innerHTML = '<p> Nenhum boleto cadastrado ainda! </p>';
        return;
    }

    for (let boleto of boletos) {
        const boletoDiv = document.createElement("div");
        boletoDiv.classList.add('boleto-item');
        const dias = getDiasVencimento(boleto.dataVencF);
        const juros = parseFloat(boleto.jurosF || 0);
        const diasOverdue = Math.max(0, -dias);
        const valorTotal = parseFloat(boleto.valorBoleto || 0) + (parseFloat(boleto.valorBoleto || 0) * (juros / 100) * diasOverdue);
        boletoDiv.innerHTML = `
        <strong> Fornecedor: </strong> ${boleto.nomeFornecedor} <br>
        <strong> Valor: </strong> R$ ${boleto.valorBoleto.toFixed(2)} <br>
        <strong> Data de Vencimento: </strong> ${boleto.dataVencF} <br>
        <strong> Prazo: </strong> ${calcularDiasVencimento(boleto.dataVencF)} <br>
        <strong> Juros: </strong> ${boleto.jurosF}% <br>
        <strong> Status: </strong> ${boleto.statusF} <br>
        <strong> Valor Total: </strong> R$ ${valorTotal.toFixed(2)} <br>        
        <button class="btn-Excluir" data-id="${boleto.id}"> Excluir </button>
        `
        listaBoletosDiv.appendChild(boletoDiv);
    }
    
}

function calcularDiasVencimento(dataVenc) {
    if (!dataVenc) return 'Data inválida';
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 'Data inválida';
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);

    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);

    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    if (Number.isNaN(diffDias)) return 'Data inválida';
    if (diffDias > 0) return `Faltam ${diffDias} dia${diffDias > 1 ? 's' : ''}`;
    if (diffDias === 0) return 'Vence hoje';
    return `Vencido há ${Math.abs(diffDias)} dia${Math.abs(diffDias) > 1 ? 's' : ''}`;
}

function getDiasVencimento(dataVenc) {
    if (!dataVenc) return 0;
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 0;
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);
    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    return Number.isNaN(diffDias) ? 0 : diffDias;
}

async function excluirBoleto(idBoleto) {
    try {
        const documentoDeletar = doc(db, "boletos", idBoleto);
        await deleteDoc(documentoDeletar);
        console.log("Boleto com ID " + idBoleto + " foi excluído.");
        return true;
    } catch (erro) {
        console.log("Erro ao excluir boleto", erro);
        alert("Ocorreu um erro ao excluir o boleto. Tente novamente!");
        return false;
    }
}

let edicao = null;

async function lidarClique(eventoDeClique){
    const btnExcluir = eventoDeClique.target.closest('.btn-Excluir');
    if (btnExcluir) {
        const idBoleto = btnExcluir.getAttribute('data-id');
        const sucesso = await excluirBoleto(idBoleto);
        if (sucesso) {
            carregarListaDeBoletos();
        }
    }
}
window.addEventListener("DOMContentLoaded", carregarListaDeBoletos);
document.addEventListener('click', lidarClique);