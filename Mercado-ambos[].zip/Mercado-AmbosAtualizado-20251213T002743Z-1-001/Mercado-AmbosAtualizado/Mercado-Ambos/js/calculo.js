function calcularJurosCliente() {
    const jurosVal = parseFloat(document.getElementById('jurosC')?.value);
    const diasVal = parseFloat(document.getElementById('diasC')?.value);
    const valorVal = parseFloat(document.getElementById('valorC')?.value);

    if (Number.isNaN(jurosVal) || Number.isNaN(diasVal) || Number.isNaN(valorVal)) {
        document.getElementById('valorTotalC').innerText = 'É necessário informar os dias corretamente.';
        return;
    }

    const valorTotalC = valorVal + (valorVal * (jurosVal / 100) * diasVal);

    document.getElementById('valorTotalC').innerText = valorTotalC.toFixed(2);
}

window.calcularJurosCliente = calcularJurosCliente;