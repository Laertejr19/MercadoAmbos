
import { db } from "./firebaseConfig.js";
import { collection, getDocs, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/12.6.0/firebase-firestore.js";

async function buscarContas() {
    try {
        const dadosBanco = await getDocs(collection(db, "contas"));
        const contas = [];

        for (const doc of dadosBanco.docs) {
            contas.push({ id: doc.id, ...doc.data() });
        }

        return contas;
    } catch (erro) {
        console.log("Erro ao buscar contas: ", erro);
        return [];
    }
}

let listaContasDiv;

async function carregarListaDeContas() {
    listaContasDiv = document.getElementById("listar-contas");
    if (!listaContasDiv) {
        console.log('Elemento #listar-contas não encontrado no DOM');
        return;
    }
    listaContasDiv.innerHTML = '<p> Carregando lista de contas ... </p>';
    try{
        const contas = await buscarContas();
        console.log(contas);
        renderizarListaDeContas(contas);
    }catch(error){
        console.log("Erro ao carregar a lista de contas: ", error);
        listaContasDiv.innerHTML = '<p> Erro ao carregar a lista de contas </p>';
    }
}

function renderizarListaDeContas(contas) {
    listaContasDiv.innerHTML = "";
    if (contas.length === 0) {
        listaContasDiv.innerHTML = '<p> Nenhuma conta cadastrada ainda! </p>';
        return;
    }

    for (let conta of contas) {
        const contaDiv = document.createElement("div");
        contaDiv.classList.add('conta-item');
        const valor = (typeof conta.valorConta === 'number') ? conta.valorConta.toFixed(2) : parseFloat(conta.valorConta || 0).toFixed(2);
        const dias = getDiasVencimento(conta.dataVencC);
        const juros = parseFloat(conta.jurosC || 0);
        const diasOverdue = Math.max(0, -dias);
        const valorTotal = parseFloat(conta.valorConta || 0) + (parseFloat(conta.valorConta || 0) * (juros / 100) * diasOverdue);
        contaDiv.innerHTML = `
        <strong> Nome: </strong> ${conta.nomeCliente} <br>
        <strong> Valor: </strong> R$ ${valor} <br>
        <strong> Data de Vencimento: </strong> ${conta.dataVencC} <br>
        <strong> Prazo: </strong> ${calcularDiasVencimento(conta.dataVencC)} <br>
        <strong> Juros: </strong> ${conta.jurosC}% <br>
        <strong> Status: </strong> ${conta.statusC} <br>
        <strong> Valor Total: </strong> R$ ${valorTotal.toFixed(2)} <br>
        <button class="btn-Excluir" data-id="${conta.id}"> Excluir </button>
        `
        listaContasDiv.appendChild(contaDiv);
    }
}



async function excluirConta(idConta) {
    try {
        const documentoDeletar = doc(db, "contas", idConta);
        await deleteDoc(documentoDeletar);
        console.log("Conta com ID " + idConta + " foi excluída.");
        return true;
    } catch (erro) {
        console.log("Erro ao excluir conta", erro);
        alert("Ocorreu um erro ao excluir a conta. Tente novamente!");
        return false;
    }
}

let edicao = null;

async function lidarClique(eventoDeClique){
    const btnExcluir = eventoDeClique.target.closest('.btn-Excluir');
    if (btnExcluir) {
        const idConta = btnExcluir.getAttribute('data-id');
        const sucesso = await excluirConta(idConta);
        if (sucesso) {
            carregarListaDeContas();
        }
    }


}

function calcularDiasVencimento(dataVenc) {
    if (!dataVenc) return 'Data inválida';
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 'Data inválida';
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);
    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    if (Number.isNaN(diffDias)) return 'Data inválida';
    if (diffDias > 0) return `Faltam ${diffDias} dia${diffDias > 1 ? 's' : ''}`;
    if (diffDias === 0) return 'Vence hoje';
    return `Vencido há ${Math.abs(diffDias)} dia${Math.abs(diffDias) > 1 ? 's' : ''}`;
}

function getDiasVencimento(dataVenc) {
    if (!dataVenc) return 0;
    const partes = dataVenc.split('-');
    if (partes.length < 3) return 0;
    const [ano, mes, dia] = partes.map(Number);
    const venc = new Date(ano, mes - 1, dia);
    const hoje = new Date();
    hoje.setHours(0,0,0,0);
    venc.setHours(0,0,0,0);
    const diffDias = Math.round((venc - hoje) / (1000 * 60 * 60 * 24));
    return Number.isNaN(diffDias) ? 0 : diffDias;
}


window.addEventListener("DOMContentLoaded", carregarListaDeContas);
document.addEventListener('click', lidarClique);